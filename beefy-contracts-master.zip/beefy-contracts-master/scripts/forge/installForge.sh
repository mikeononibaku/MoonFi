curl -L https://foundry.paradigm.xyz | bash
foundryup