module.exports = {
  contracts_directory: "./contracts/BIFI",

  compilers: {
    solc: {
      version: "0.6.12",
    },
  },
};

// This file is needed for truffle-flattener, do not remove!
