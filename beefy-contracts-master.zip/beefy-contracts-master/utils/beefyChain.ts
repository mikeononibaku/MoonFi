import { ChainId } from "blockchain-addressbook";

export type BeefyChain = keyof typeof ChainId | "localhost";